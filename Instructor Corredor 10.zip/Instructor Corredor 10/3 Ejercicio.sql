
CREATE DATABASE HospitalDB;
GO
USE HospitalDB;
GO

CREATE PROCEDURE sp_crear_tabla_pacientes
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Pacientes' AND xtype='U')
    BEGIN
        CREATE TABLE Pacientes (
            PacienteID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Apellido VARCHAR(50) NOT NULL,
            FechaNacimiento DATE NOT NULL,
            Genero CHAR(1) CHECK(Genero IN ('M','F')),
            Telefono VARCHAR(20) UNIQUE
        )
    END
END;
GO
EXEC sp_crear_tabla_pacientes;
GO


CREATE PROCEDURE sp_crear_tabla_doctores
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Doctores' AND xtype='U')
    BEGIN
        CREATE TABLE Doctores (
            DoctorID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Apellido VARCHAR(50) NOT NULL,
            Especialidad VARCHAR(100) NOT NULL,
            Email VARCHAR(100) UNIQUE
        )
    END
END;
GO
EXEC sp_crear_tabla_doctores;
GO


CREATE PROCEDURE sp_crear_tabla_habitaciones
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Habitaciones' AND xtype='U')
    BEGIN
        CREATE TABLE Habitaciones (
            HabitacionID INT PRIMARY KEY IDENTITY,
            Numero INT UNIQUE NOT NULL,
            Tipo VARCHAR(50) CHECK(Tipo IN ('General','UCI','Privada')),
            Estado VARCHAR(20) CHECK(Estado IN ('Disponible','Ocupada')) DEFAULT 'Disponible'
        )
    END
END;
GO
EXEC sp_crear_tabla_habitaciones;
GO


CREATE PROCEDURE sp_crear_tabla_citas
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Citas' AND xtype='U')
    BEGIN
        CREATE TABLE Citas (
            CitaID INT PRIMARY KEY IDENTITY,
            PacienteID INT FOREIGN KEY REFERENCES Pacientes(PacienteID),
            DoctorID INT FOREIGN KEY REFERENCES Doctores(DoctorID),
            FechaCita DATETIME NOT NULL,
            Estado VARCHAR(20) CHECK(Estado IN ('Pendiente','Realizada','Cancelada')) DEFAULT 'Pendiente'
        )
    END
END;
GO
EXEC sp_crear_tabla_citas;
GO


CREATE PROCEDURE sp_crear_tabla_tratamientos
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Tratamientos' AND xtype='U')
    BEGIN
        CREATE TABLE Tratamientos (
            TratamientoID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(100) NOT NULL,
            Costo DECIMAL(10,2) CHECK(Costo >= 0)
        )
    END
END;
GO
EXEC sp_crear_tabla_tratamientos;
GO

CREATE PROCEDURE sp_crear_tabla_hospitalizaciones
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Hospitalizaciones' AND xtype='U')
    BEGIN
        CREATE TABLE Hospitalizaciones (
            HospID INT PRIMARY KEY IDENTITY,
            PacienteID INT FOREIGN KEY REFERENCES Pacientes(PacienteID),
            HabitacionID INT FOREIGN KEY REFERENCES Habitaciones(HabitacionID),
            FechaIngreso DATE NOT NULL,
            FechaAlta DATE NULL
        )
    END
END;
GO
EXEC sp_crear_tabla_hospitalizaciones;
GO


CREATE PROCEDURE sp_crear_tabla_medicamentos
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Medicamentos' AND xtype='U')
    BEGIN
        CREATE TABLE Medicamentos (
            MedicamentoID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(100) NOT NULL,
            Stock INT CHECK(Stock >= 0),
            Precio DECIMAL(10,2) CHECK(Precio >= 0)
        )
    END
END;
GO
EXEC sp_crear_tabla_medicamentos;
GO


CREATE PROCEDURE sp_insertar_paciente
    @Nombre VARCHAR(50),
    @Apellido VARCHAR(50),
    @FechaNacimiento DATE,
    @Genero CHAR(1),
    @Telefono VARCHAR(20)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Pacientes WHERE Telefono=@Telefono)
    BEGIN
        PRINT 'El paciente ya está registrado con ese teléfono.';
        RETURN;
    END
    INSERT INTO Pacientes (Nombre,Apellido,FechaNacimiento,Genero,Telefono)
    VALUES (@Nombre,@Apellido,@FechaNacimiento,@Genero,@Telefono)
END;
GO


CREATE PROCEDURE sp_insertar_doctor
    @Nombre VARCHAR(50),
    @Apellido VARCHAR(50),
    @Especialidad VARCHAR(100),
    @Email VARCHAR(100)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Doctores WHERE Email=@Email)
    BEGIN
        PRINT 'Doctor ya registrado con ese email.';
        RETURN;
    END
    INSERT INTO Doctores (Nombre,Apellido,Especialidad,Email)
    VALUES (@Nombre,@Apellido,@Especialidad,@Email)
END;
GO


CREATE PROCEDURE sp_insertar_habitacion
    @Numero INT,
    @Tipo VARCHAR(50),
    @Estado VARCHAR(20) = 'Disponible'
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Habitaciones WHERE Numero=@Numero)
    BEGIN
        PRINT 'Ya existe esa habitación.';
        RETURN;
    END
    INSERT INTO Habitaciones (Numero,Tipo,Estado)
    VALUES (@Numero,@Tipo,@Estado)
END;
GO

CREATE PROCEDURE sp_insertar_cita
    @PacienteID INT,
    @DoctorID INT,
    @FechaCita DATETIME
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Pacientes WHERE PacienteID=@PacienteID)
    BEGIN
        PRINT 'Paciente no existe.';
        RETURN;
    END
    IF NOT EXISTS (SELECT 1 FROM Doctores WHERE DoctorID=@DoctorID)
    BEGIN
        PRINT 'Doctor no existe.';
        RETURN;
    END
    INSERT INTO Citas (PacienteID,DoctorID,FechaCita)
    VALUES (@PacienteID,@DoctorID,@FechaCita)
END;
GO


CREATE PROCEDURE sp_insertar_tratamiento
    @Nombre VARCHAR(100),
    @Costo DECIMAL(10,2)
AS
BEGIN
    INSERT INTO Tratamientos (Nombre,Costo)
    VALUES (@Nombre,@Costo)
END;
GO


CREATE PROCEDURE sp_insertar_hospitalizacion
    @PacienteID INT,
    @HabitacionID INT,
    @FechaIngreso DATE
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Pacientes WHERE PacienteID=@PacienteID)
    BEGIN
        PRINT 'Paciente no existe.';
        RETURN;
    END
    IF NOT EXISTS (SELECT 1 FROM Habitaciones WHERE HabitacionID=@HabitacionID)
    BEGIN
        PRINT 'Habitación no existe.';
        RETURN;
    END
    UPDATE Habitaciones SET Estado='Ocupada' WHERE HabitacionID=@HabitacionID;
    INSERT INTO Hospitalizaciones (PacienteID,HabitacionID,FechaIngreso)
    VALUES (@PacienteID,@HabitacionID,@FechaIngreso)
END;
GO


CREATE PROCEDURE sp_insertar_medicamento
    @Nombre VARCHAR(100),
    @Stock INT,
    @Precio DECIMAL(10,2)
AS
BEGIN
    INSERT INTO Medicamentos (Nombre,Stock,Precio)
    VALUES (@Nombre,@Stock,@Precio)
END;
GO


EXEC sp_insertar_paciente 'Juan','Pérez','1985-05-10','M','3001111111';
EXEC sp_insertar_paciente 'Ana','Gómez','1990-07-20','F','3002222222';
EXEC sp_insertar_paciente 'Luis','Martínez','1978-03-15','M','3003333333';
EXEC sp_insertar_paciente 'María','López','1982-12-01','F','3004444444';
EXEC sp_insertar_paciente 'Pedro','Ramírez','1995-09-09','M','3005555555';
EXEC sp_insertar_paciente 'Lucía','Fernández','1987-11-30','F','3006666666';
EXEC sp_insertar_paciente 'Carlos','Torres','2000-06-22','M','3007777777';
EXEC sp_insertar_paciente 'Laura','Jiménez','1992-04-18','F','3008888888';
EXEC sp_insertar_paciente 'Diego','Castro','1989-08-05','M','3009999999';
EXEC sp_insertar_paciente 'Paola','Hernández','1993-10-14','F','3010000000';


EXEC sp_insertar_doctor 'Andrés','Santos','Cardiología','andres@hospital.com';
EXEC sp_insertar_doctor 'Beatriz','Mora','Pediatría','beatriz@hospital.com';
EXEC sp_insertar_doctor 'Camilo','Pardo','Cirugía','camilo@hospital.com';
EXEC sp_insertar_doctor 'Daniela','Vargas','Neurología','daniela@hospital.com';
EXEC sp_insertar_doctor 'Esteban','Suárez','Medicina Interna','esteban@hospital.com';
EXEC sp_insertar_doctor 'Felipe','López','Traumatología','felipe@hospital.com';
EXEC sp_insertar_doctor 'Gabriela','Moreno','Oncología','gabriela@hospital.com';
EXEC sp_insertar_doctor 'Héctor','Silva','Dermatología','hector@hospital.com';
EXEC sp_insertar_doctor 'Isabel','Cruz','Psiquiatría','isabel@hospital.com';
EXEC sp_insertar_doctor 'Jorge','Castillo','Ginecología','jorge@hospital.com';

EXEC sp_insertar_habitacion 101,'General','Disponible';
EXEC sp_insertar_habitacion 102,'UCI','Disponible';
EXEC sp_insertar_habitacion 103,'Privada','Disponible';
EXEC sp_insertar_habitacion 104,'General','Disponible';
EXEC sp_insertar_habitacion 105,'Privada','Disponible';
EXEC sp_insertar_habitacion 106,'General','Disponible';
EXEC sp_insertar_habitacion 107,'UCI','Disponible';
EXEC sp_insertar_habitacion 108,'General','Disponible';
EXEC sp_insertar_habitacion 109,'Privada','Disponible';
EXEC sp_insertar_habitacion 110,'General','Disponible';

EXEC sp_insertar_tratamiento 'Terapia Física',200000;
EXEC sp_insertar_tratamiento 'Quimioterapia',1500000;
EXEC sp_insertar_tratamiento 'Radioterapia',1200000;
EXEC sp_insertar_tratamiento 'Cirugía Cardiaca',5000000;
EXEC sp_insertar_tratamiento 'Consulta General',80000;
EXEC sp_insertar_tratamiento 'Diálisis',1000000;
EXEC sp_insertar_tratamiento 'Vacunación',50000;
EXEC sp_insertar_tratamiento 'Cesárea',3000000;
EXEC sp_insertar_tratamiento 'Transfusión Sanguínea',400000;
EXEC sp_insertar_tratamiento 'Examen de Laboratorio',100000;


EXEC sp_insertar_medicamento 'Paracetamol',500,2000;
EXEC sp_insertar_medicamento 'Ibuprofeno',300,2500;
EXEC sp_insertar_medicamento 'Amoxicilina',200,5000;
EXEC sp_insertar_medicamento 'Omeprazol',400,3500;
EXEC sp_insertar_medicamento 'Metformina',250,6000;
EXEC sp_insertar_medicamento 'Losartán',180,7000;
EXEC sp_insertar_medicamento 'Atorvastatina',220,8000;
EXEC sp_insertar_medicamento 'Insulina',150,20000;
EXEC sp_insertar_medicamento 'Clonazepam',100,12000;
EXEC sp_insertar_medicamento 'Vitamina C',600,1500;


EXEC sp_insertar_cita 1,1,'2025-09-15 09:00';
EXEC sp_insertar_cita 2,2,'2025-09-16 10:30';
EXEC sp_insertar_cita 3,3,'2025-09-17 14:00';
EXEC sp_insertar_cita 4,4,'2025-09-18 08:00';
EXEC sp_insertar_cita 5,5,'2025-09-18 15:00';
EXEC sp_insertar_cita 6,6,'2025-09-19 09:30';
EXEC sp_insertar_cita 7,7,'2025-09-19 11:00';
EXEC sp_insertar_cita 8,8,'2025-09-20 13:00';
EXEC sp_insertar_cita 9,9,'2025-09-21 10:00';
EXEC sp_insertar_cita 10,10,'2025-09-22 16:00';


EXEC sp_insertar_hospitalizacion 1,1,'2025-09-01';
EXEC sp_insertar_hospitalizacion 2,2,'2025-09-02';
EXEC sp_insertar_hospitalizacion 3,3,'2025-09-03';
EXEC sp_insertar_hospitalizacion 4,4,'2025-09-04';
EXEC sp_insertar_hospitalizacion 5,5,'2025-09-05';
EXEC sp_insertar_hospitalizacion 6,6,'2025-09-06';
EXEC sp_insertar_hospitalizacion 7,7,'2025-09-07';
EXEC sp_insertar_hospitalizacion 8,8,'2025-09-08';
EXEC sp_insertar_hospitalizacion 9,9,'2025-09-09';
EXEC sp_insertar_hospitalizacion 10,10,'2025-09-10';


   
CREATE VIEW vw_pacientes_hospitalizados AS
SELECT p.Nombre,p.Apellido,h.Numero,h.Tipo,h.Estado
FROM Pacientes p
JOIN Hospitalizaciones hs ON p.PacienteID=hs.PacienteID
JOIN Habitaciones h ON hs.HabitacionID=h.HabitacionID;
GO


CREATE VIEW vw_citas_pendientes_doctor AS
SELECT d.Nombre,d.Apellido,COUNT(c.CitaID) AS TotalPendientes
FROM Doctores d
JOIN Citas c ON d.DoctorID=c.DoctorID
WHERE c.Estado='Pendiente'
GROUP BY d.Nombre,d.Apellido;
GO

CREATE VIEW vw_promedio_tratamientos AS
SELECT AVG(Costo) AS PromedioCosto
FROM Tratamientos;
GO


CREATE VIEW vw_medicamentos_bajo_stock AS
SELECT Nombre,Stock,Precio
FROM Medicamentos
WHERE Stock < 200;
GO


CREATE VIEW vw_pacientes_por_especialidad AS
SELECT d.Especialidad,COUNT(c.CitaID) AS PacientesAtendidos
FROM Doctores d
JOIN Citas c ON d.DoctorID=c.DoctorID
GROUP BY d.Especialidad;
GO
