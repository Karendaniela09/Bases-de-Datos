
CREATE DATABASE Supermercado;
GO
USE Supermercado;
GO


CREATE PROCEDURE sp_crear_tabla_clientes
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Clientes' AND xtype='U')
    BEGIN
        CREATE TABLE Clientes (
            ClienteID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Apellido VARCHAR(50) NOT NULL,
            Telefono VARCHAR(20),
            Email VARCHAR(100) UNIQUE,
            FechaRegistro DATE DEFAULT GETDATE()
        )
    END
END;
GO
EXEC sp_crear_tabla_clientes;
GO


CREATE PROCEDURE sp_crear_tabla_productos
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Productos' AND xtype='U')
    BEGIN
        CREATE TABLE Productos (
            ProductoID INT PRIMARY KEY IDENTITY,
            NombreProducto VARCHAR(100) NOT NULL,
            Categoria VARCHAR(50),
            Precio DECIMAL(10,2) CHECK (Precio > 0),
            Stock INT CHECK (Stock >= 0)
        )
    END
END;
GO
EXEC sp_crear_tabla_productos;
GO

CREATE PROCEDURE sp_crear_tabla_empleados
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Empleados' AND xtype='U')
    BEGIN
        CREATE TABLE Empleados (
            EmpleadoID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Apellido VARCHAR(50) NOT NULL,
            Cargo VARCHAR(50),
            Telefono VARCHAR(20),
            Email VARCHAR(100) UNIQUE
        )
    END
END;
GO
EXEC sp_crear_tabla_empleados;
GO


CREATE PROCEDURE sp_crear_tabla_proveedores
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Proveedores' AND xtype='U')
    BEGIN
        CREATE TABLE Proveedores (
            ProveedorID INT PRIMARY KEY IDENTITY,
            NombreProveedor VARCHAR(100) NOT NULL,
            Telefono VARCHAR(20),
            Email VARCHAR(100) UNIQUE,
            Direccion VARCHAR(150)
        )
    END
END;
GO
EXEC sp_crear_tabla_proveedores;
GO


CREATE PROCEDURE sp_crear_tabla_ventas
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Ventas' AND xtype='U')
    BEGIN
        CREATE TABLE Ventas (
            VentaID INT PRIMARY KEY IDENTITY,
            ClienteID INT FOREIGN KEY REFERENCES Clientes(ClienteID),
            EmpleadoID INT FOREIGN KEY REFERENCES Empleados(EmpleadoID),
            FechaVenta DATETIME DEFAULT GETDATE(),
            Total DECIMAL(10,2) CHECK (Total >= 0)
        )
    END
END;
GO
EXEC sp_crear_tabla_ventas;
GO

CREATE PROCEDURE sp_crear_tabla_detalleventa
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='DetalleVenta' AND xtype='U')
    BEGIN
        CREATE TABLE DetalleVenta (
            DetalleID INT PRIMARY KEY IDENTITY,
            VentaID INT FOREIGN KEY REFERENCES Ventas(VentaID),
            ProductoID INT FOREIGN KEY REFERENCES Productos(ProductoID),
            Cantidad INT CHECK (Cantidad > 0),
            Subtotal DECIMAL(10,2) CHECK (Subtotal >= 0)
        )
    END
END;
GO
EXEC sp_crear_tabla_detalleventa;
GO


CREATE PROCEDURE sp_crear_tabla_inventario
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Inventario' AND xtype='U')
    BEGIN
        CREATE TABLE Inventario (
            InventarioID INT PRIMARY KEY IDENTITY,
            ProductoID INT FOREIGN KEY REFERENCES Productos(ProductoID),
            StockActual INT CHECK (StockActual >= 0),
            UltimaActualizacion DATETIME DEFAULT GETDATE()
        )
    END
END;
GO
EXEC sp_crear_tabla_inventario;
GO


CREATE PROCEDURE sp_insertar_cliente
    @Nombre VARCHAR(50),
    @Apellido VARCHAR(50),
    @Telefono VARCHAR(20),
    @Email VARCHAR(100)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Clientes WHERE Email=@Email)
    BEGIN
        PRINT ' Cliente ya existe';
        RETURN;
    END
    INSERT INTO Clientes (Nombre,Apellido,Telefono,Email) VALUES (@Nombre,@Apellido,@Telefono,@Email);
END;
GO

EXEC sp_insertar_cliente 'Camila','Ramírez','3101111111','camila@sup.com';
EXEC sp_insertar_cliente 'Juan','Pérez','3102222222','juan@sup.com';
EXEC sp_insertar_cliente 'Sofía','López','3103333333','sofia@sup.com';
EXEC sp_insertar_cliente 'Carlos','Martínez','3104444444','carlos@sup.com';
EXEC sp_insertar_cliente 'Valentina','Morales','3105555555','valentina@sup.com';
EXEC sp_insertar_cliente 'Diego','Hernández','3106666666','diego@sup.com';
EXEC sp_insertar_cliente 'Laura','Castro','3107777777','laura@sup.com';
EXEC sp_insertar_cliente 'Andrés','García','3108888888','andres@sup.com';
EXEC sp_insertar_cliente 'Natalia','Ortiz','3109999999','natalia@sup.com';
EXEC sp_insertar_cliente 'Felipe','Vega','3110000000','felipe@sup.com';


CREATE PROCEDURE sp_insertar_producto
    @NombreProducto VARCHAR(100),
    @Categoria VARCHAR(50),
    @Precio DECIMAL(10,2),
    @Stock INT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Productos WHERE NombreProducto=@NombreProducto)
    BEGIN
        PRINT ' Producto ya existe';
        RETURN;
    END
    INSERT INTO Productos (NombreProducto,Categoria,Precio,Stock) VALUES (@NombreProducto,@Categoria,@Precio,@Stock);
END;
GO


EXEC sp_insertar_producto 'Arroz 1kg','Granos',3500,100;
EXEC sp_insertar_producto 'Frijoles 1kg','Granos',4000,80;
EXEC sp_insertar_producto 'Leche 1L','Lácteos',3200,150;
EXEC sp_insertar_producto 'Queso 500g','Lácteos',8000,70;
EXEC sp_insertar_producto 'Huevos 30u','Proteínas',12000,60;
EXEC sp_insertar_producto 'Carne Res 1kg','Proteínas',25000,50;
EXEC sp_insertar_producto 'Pan Tajado','Panadería',4500,90;
EXEC sp_insertar_producto 'Aceite 1L','Aceites',12000,120;
EXEC sp_insertar_producto 'Manzanas 1kg','Frutas',6000,40;
EXEC sp_insertar_producto 'Bananas 1kg','Frutas',5000,55;


CREATE PROCEDURE sp_insertar_proveedor
    @NombreProveedor VARCHAR(100),
    @Telefono VARCHAR(20),
    @Email VARCHAR(100),
    @Direccion VARCHAR(150)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Proveedores WHERE Email=@Email)
    BEGIN
        PRINT ' Proveedor ya existe';
        RETURN;
    END
    INSERT INTO Proveedores (NombreProveedor,Telefono,Email,Direccion) VALUES (@NombreProveedor,@Telefono,@Email,@Direccion);
END;
GO

EXEC sp_insertar_proveedor 'Distribuidora Central','3201111111','central@sup.com','Calle 10 #5-20';
EXEC sp_insertar_proveedor 'Lácteos Andinos','3202222222','lacteos@sup.com','Carrera 15 #20-40';
EXEC sp_insertar_proveedor 'Granos Norte','3203333333','granos@sup.com','Calle 30 #12-60';
EXEC sp_insertar_proveedor 'Carnes Premium','3204444444','carnes@sup.com','Cra 7 #50-25';
EXEC sp_insertar_proveedor 'Frutas del Valle','3205555555','frutas@sup.com','Av 3 #70-10';
EXEC sp_insertar_proveedor 'Panadería La 14','3206666666','pan@sup.com','Calle 8 #9-12';
EXEC sp_insertar_proveedor 'Aceites El Dorado','3207777777','aceites@sup.com','Cra 45 #80-30';
EXEC sp_insertar_proveedor 'Verduras Frescas','3208888888','verduras@sup.com','Calle 60 #33-45';
EXEC sp_insertar_proveedor 'Huevos del Campo','3209999999','huevos@sup.com','Cra 22 #11-55';
EXEC sp_insertar_proveedor 'Importadora Caribe','3210000000','caribe@sup.com','Av 80 #90-20');

/
CREATE PROCEDURE sp_insertar_empleado
    @Nombre VARCHAR(50),
    @Apellido VARCHAR(50),
    @Cargo VARCHAR(50),
    @Telefono VARCHAR(20),
    @Email VARCHAR(100)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Empleados WHERE Email=@Email)
    BEGIN
        PRINT ' Empleado ya existe';
        RETURN;
    END
    INSERT INTO Empleados (Nombre,Apellido,Cargo,Telefono,Email) VALUES (@Nombre,@Apellido,@Cargo,@Telefono,@Email);
END;
GO

EXEC sp_insertar_empleado 'Luis','Mendoza','Cajero','3001111111','luis@sup.com';
EXEC sp_insertar_empleado 'Paula','Gómez','Vendedor','3002222222','paula@sup.com';
EXEC sp_insertar_empleado 'Jorge','López','Administrador','3003333333','jorge@sup.com';
EXEC sp_insertar_empleado 'Carolina','Ríos','Cajera','3004444444','caro@sup.com';
EXEC sp_insertar_empleado 'Andrés','Martínez','Reponedor','3005555555','andres@sup.com';
EXEC sp_insertar_empleado 'Natalia','Castro','Vendedora','3006666666','natalia@sup.com';
EXEC sp_insertar_empleado 'Felipe','Suárez','Seguridad','3007777777','felipe@sup.com';
EXEC sp_insertar_empleado 'Valeria','Ramírez','Vendedora','3008888888','valeria@sup.com';
EXEC sp_insertar_empleado 'Camilo','Torres','Cajero','3009999999','camilo@sup.com';
EXEC sp_insertar_empleado 'Mariana','Ortiz','Gerente','3010000000','mariana@sup.com');


CREATE PROCEDURE sp_insertar_venta
    @ClienteID INT,
    @EmpleadoID INT,
    @Total DECIMAL(10,2)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Clientes WHERE ClienteID=@ClienteID)
    BEGIN
        PRINT ' Cliente no existe';
        RETURN;
    END
    IF NOT EXISTS (SELECT 1 FROM Empleados WHERE EmpleadoID=@EmpleadoID)
    BEGIN
        PRINT ' Empleado no existe';
        RETURN;
    END
    INSERT INTO Ventas (ClienteID,EmpleadoID,Total) VALUES (@ClienteID,@EmpleadoID,@Total);
END;
GO


EXEC sp_insertar_venta 1,1,35000;
EXEC sp_insertar_venta 2,2,50000;
EXEC sp_insertar_venta 3,3,22000;
EXEC sp_insertar_venta 4,4,60000;
EXEC sp_insertar_venta 5,5,45000;
EXEC sp_insertar_venta 6,6,38000;
EXEC sp_insertar_venta 7,7,70000;
EXEC sp_insertar_venta 8,8,25000;
EXEC sp_insertar_venta 9,9,32000;
EXEC sp_insertar_venta 10,10,40000;


CREATE PROCEDURE sp_insertar_detalleventa
    @VentaID INT,
    @ProductoID INT,
    @Cantidad INT,
    @Subtotal DECIMAL(10,2)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Ventas WHERE VentaID=@VentaID)
    BEGIN
        PRINT ' Venta no existe';
        RETURN;
    END
    IF NOT EXISTS (SELECT 1 FROM Productos WHERE ProductoID=@ProductoID)
    BEGIN
        PRINT ' Producto no existe';
        RETURN;
    END
    INSERT INTO DetalleVenta (VentaID,ProductoID,Cantidad,Subtotal) VALUES (@VentaID,@ProductoID,@Cantidad,@Subtotal);
END;
GO


EXEC sp_insertar_detalleventa 1,1,5,17500;
EXEC sp_insertar_detalleventa 2,2,4,16000;
EXEC sp_insertar_detalleventa 3,3,3,9600;
EXEC sp_insertar_detalleventa 4,4,2,16000;
EXEC sp_insertar_detalleventa 5,5,1,12000;
EXEC sp_insertar_detalleventa 6,6,2,50000;
EXEC sp_insertar_detalleventa 7,7,4,18000;
EXEC sp_insertar_detalleventa 8,8,3,36000;
EXEC sp_insertar_detalleventa 9,9,2,12000;
EXEC sp_insertar_detalleventa 10,10,5,25000;

CREATE PROCEDURE sp_insertar_inventario
    @ProductoID INT,
    @StockActual INT
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Productos WHERE ProductoID=@ProductoID)
    BEGIN
        PRINT ' Producto no existe';
        RETURN;
    END
    INSERT INTO Inventario (ProductoID,StockActual) VALUES (@ProductoID,@StockActual);
END;
GO


EXEC sp_insertar_inventario 1,100;
EXEC sp_insertar_inventario 2,80;
EXEC sp_insertar_inventario 3,150;
EXEC sp_insertar_inventario 4,70;
EXEC sp_insertar_inventario 5,60;
EXEC sp_insertar_inventario 6,50;
EXEC sp_insertar_inventario 7,90;
EXEC sp_insertar_inventario 8,120;
EXEC sp_insertar_inventario 9,40;
EXEC sp_insertar_inventario 10,55;


CREATE VIEW vw_ventas_cliente AS
SELECT c.Nombre,c.Apellido,SUM(v.Total) AS TotalComprado
FROM Clientes c
JOIN Ventas v ON c.ClienteID=v.ClienteID
GROUP BY c.Nombre,c.Apellido;


CREATE VIEW vw_productos_bajo_stock AS
SELECT NombreProducto,Stock
FROM Productos
WHERE Stock < 20;

CREATE VIEW vw_ventas_empleado AS
SELECT e.Nombre,e.Apellido,COUNT(v.VentaID) AS NumVentas
FROM Empleados e
JOIN Ventas v ON e.EmpleadoID=v.EmpleadoID
GROUP BY e.Nombre,e.Apellido;


CREATE VIEW vw_inventario_actual AS
SELECT p.NombreProducto,i.StockActual,i.UltimaActualizacion
FROM Inventario i
JOIN Productos p ON i.ProductoID=p.ProductoID;


CREATE VIEW vw_productos_mas_vendidos AS
SELECT p.NombreProducto,SUM(d.Cantidad) AS TotalVendido
FROM DetalleVenta d
JOIN Productos p ON d.ProductoID=p.ProductoID
GROUP BY p.NombreProducto
ORDER BY TotalVendido DESC;
