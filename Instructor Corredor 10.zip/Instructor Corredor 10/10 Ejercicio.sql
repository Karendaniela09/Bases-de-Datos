
CREATE DATABASE Cafeteria;
GO
USE Cafeteria;
GO


CREATE PROCEDURE sp_crear_tabla_clientes
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Clientes' AND xtype='U')
    BEGIN
        CREATE TABLE Clientes (
            ClienteID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Apellido VARCHAR(50) NOT NULL,
            Telefono VARCHAR(20),
            Email VARCHAR(100) UNIQUE
        );
    END
END;
GO
EXEC sp_crear_tabla_clientes;


CREATE PROCEDURE sp_crear_tabla_proveedores
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Proveedores' AND xtype='U')
    BEGIN
        CREATE TABLE Proveedores (
            ProveedorID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(100) NOT NULL,
            Telefono VARCHAR(20),
            Direccion VARCHAR(100),
            Email VARCHAR(100) UNIQUE
        );
    END
END;
GO
EXEC sp_crear_tabla_proveedores;

CREATE PROCEDURE sp_crear_tabla_categorias
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Categorias' AND xtype='U')
    BEGIN
        CREATE TABLE Categorias (
            CategoriaID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Descripcion VARCHAR(100)
        );
    END
END;
GO
EXEC sp_crear_tabla_categorias;


CREATE PROCEDURE sp_crear_tabla_productos
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Productos' AND xtype='U')
    BEGIN
        CREATE TABLE Productos (
            ProductoID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(100) NOT NULL,
            Precio DECIMAL(10,2) CHECK(Precio > 0),
            Stock INT CHECK(Stock >= 0),
            CategoriaID INT FOREIGN KEY REFERENCES Categorias(CategoriaID),
            ProveedorID INT FOREIGN KEY REFERENCES Proveedores(ProveedorID)
        );
    END
END;
GO
EXEC sp_crear_tabla_productos;

CREATE PROCEDURE sp_crear_tabla_empleados
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Empleados' AND xtype='U')
    BEGIN
        CREATE TABLE Empleados (
            EmpleadoID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Apellido VARCHAR(50) NOT NULL,
            Cargo VARCHAR(50),
            Telefono VARCHAR(20)
        );
    END
END;
GO
EXEC sp_crear_tabla_empleados;


CREATE PROCEDURE sp_crear_tabla_ventas
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Ventas' AND xtype='U')
    BEGIN
        CREATE TABLE Ventas (
            VentaID INT PRIMARY KEY IDENTITY,
            ClienteID INT FOREIGN KEY REFERENCES Clientes(ClienteID),
            EmpleadoID INT FOREIGN KEY REFERENCES Empleados(EmpleadoID),
            Fecha DATE DEFAULT GETDATE(),
            Total DECIMAL(10,2) CHECK(Total >= 0)
        );
    END
END;
GO
EXEC sp_crear_tabla_ventas;


CREATE PROCEDURE sp_crear_tabla_detalleventas
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='DetalleVentas' AND xtype='U')
    BEGIN
        CREATE TABLE DetalleVentas (
            DetalleID INT PRIMARY KEY IDENTITY,
            VentaID INT FOREIGN KEY REFERENCES Ventas(VentaID),
            ProductoID INT FOREIGN KEY REFERENCES Productos(ProductoID),
            Cantidad INT CHECK(Cantidad > 0),
            PrecioUnitario DECIMAL(10,2) CHECK(PrecioUnitario > 0)
        );
    END
END;
GO
EXEC sp_crear_tabla_detalleventas;

INSERT INTO Clientes (Nombre,Apellido,Telefono,Email) VALUES
('Carlos','Gómez','3101234567','carlos@gmail.com'),
('María','López','3112345678','maria@gmail.com'),
('Juan','Martínez','3123456789','juan@gmail.com'),
('Ana','Rodríguez','3134567890','ana@gmail.com'),
('Pedro','Sánchez','3145678901','pedro@gmail.com'),
('Laura','Torres','3156789012','laura@gmail.com'),
('Andrés','Ramírez','3167890123','andres@gmail.com'),
('Sofía','Morales','3178901234','sofia@gmail.com'),
('Diego','Castro','3189012345','diego@gmail.com'),
('Camila','Hernández','3190123456','camila@gmail.com');


INSERT INTO Proveedores (Nombre,Telefono,Direccion,Email) VALUES
('Café de Colombia','3201111111','Cra 10 # 20-30','prove1@gmail.com'),
('Postres S.A.','3202222222','Calle 15 # 5-25','prove2@gmail.com'),
('Panadería El Trigo','3203333333','Cra 45 # 12-50','prove3@gmail.com'),
('Chocolates Ltda','3204444444','Av 30 # 45-60','prove4@gmail.com'),
('Leche Alpina','3205555555','Cra 25 # 7-15','prove5@gmail.com'),
('Jugos Naturales','3206666666','Calle 8 # 12-40','prove6@gmail.com'),
('Quesos Gourmet','3207777777','Av 68 # 40-90','prove7@gmail.com'),
('Dulces Express','3208888888','Cra 80 # 20-10','prove8@gmail.com'),
('Helados Polar','3209999999','Calle 70 # 13-22','prove9@gmail.com'),
('Cacao Premium','3210000000','Cra 60 # 14-55','prove10@gmail.com');

INSERT INTO Categorias (Nombre,Descripcion) VALUES
('Bebidas Calientes','Café, té, chocolate'),
('Bebidas Frías','Jugos, malteadas, refrescos'),
('Postres','Tortas, galletas, flanes'),
('Panadería','Pan, croissants, arepas'),
('Snacks','Galletas, papas, maní'),
('Lácteos','Leche, yogurt, queso'),
('Helados','Variedades de helados'),
('Ensaladas','Frutas y verduras'),
('Sandwiches','Sandwiches y wraps'),
('Otros','Varios productos');


INSERT INTO Empleados (Nombre,Apellido,Cargo,Telefono) VALUES
('Lucía','Mendoza','Cajera','3221111111'),
('Andrés','Vargas','Mesero','3222222222'),
('Carolina','Reyes','Gerente','3223333333'),
('Felipe','Ortiz','Barista','3224444444'),
('Juliana','Moreno','Auxiliar','3225555555'),
('Hernán','Silva','Cocinero','3226666666'),
('Daniela','Guzmán','Cajera','3227777777'),
('Sergio','Pérez','Mesero','3228888888'),
('Natalia','Ríos','Auxiliar','3229999999'),
('Camilo','Suárez','Administrador','3230000000');


INSERT INTO Productos (Nombre,Precio,Stock,CategoriaID,ProveedorID) VALUES
('Café Americano',5000,100,1,1),
('Capuccino',7000,80,1,1),
('Té Verde',4000,50,1,1),
('Jugo de Naranja',6000,70,2,6),
('Malteada de Chocolate',8000,60,2,9),
('Torta de Chocolate',12000,40,3,2),
('Croissant',5000,50,4,3),
('Sandwich de Pollo',10000,30,9,3),
('Helado Vainilla',7000,45,7,9),
('Yogurt Griego',9000,25,6,5);


INSERT INTO Ventas
