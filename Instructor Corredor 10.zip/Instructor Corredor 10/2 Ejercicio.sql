
CREATE DATABASE UniversidadDB;
GO
USE UniversidadDB;
GO

CREATE PROCEDURE sp_crear_tabla_estudiantes
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Estudiantes' AND xtype='U')
    BEGIN
        CREATE TABLE Estudiantes (
            EstudianteID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Apellido VARCHAR(50) NOT NULL,
            Email VARCHAR(100) UNIQUE NOT NULL,
            FechaNacimiento DATE NOT NULL,
            ProgramaID INT NULL
        )
    END
END;
GO
EXEC sp_crear_tabla_estudiantes;
GO

CREATE PROCEDURE sp_crear_tabla_profesores
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Profesores' AND xtype='U')
    BEGIN
        CREATE TABLE Profesores (
            ProfesorID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Apellido VARCHAR(50) NOT NULL,
            Especialidad VARCHAR(50),
            Email VARCHAR(100) UNIQUE NOT NULL
        )
    END
END;
GO
EXEC sp_crear_tabla_profesores;
GO


CREATE PROCEDURE sp_crear_tabla_cursos
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Cursos' AND xtype='U')
    BEGIN
        CREATE TABLE Cursos (
            CursoID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(100) NOT NULL,
            Creditos INT CHECK(Creditos > 0),
            ProfesorID INT FOREIGN KEY REFERENCES Profesores(ProfesorID)
        )
    END
END;
GO
EXEC sp_crear_tabla_cursos;
GO

CREATE PROCEDURE sp_crear_tabla_programas
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Programas' AND xtype='U')
    BEGIN
        CREATE TABLE Programas (
            ProgramaID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(100) NOT NULL,
            Facultad VARCHAR(100) NOT NULL
        )
    END
END;
GO
EXEC sp_crear_tabla_programas;
GO

CREATE PROCEDURE sp_crear_tabla_matriculas
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Matriculas' AND xtype='U')
    BEGIN
        CREATE TABLE Matriculas (
            MatriculaID INT PRIMARY KEY IDENTITY,
            EstudianteID INT FOREIGN KEY REFERENCES Estudiantes(EstudianteID),
            CursoID INT FOREIGN KEY REFERENCES Cursos(CursoID),
            Fecha DATE DEFAULT GETDATE()
        )
    END
END;
GO
EXEC sp_crear_tabla_matriculas;
GO

CREATE PROCEDURE sp_crear_tabla_notas
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Notas' AND xtype='U')
    BEGIN
        CREATE TABLE Notas (
            NotaID INT PRIMARY KEY IDENTITY,
            MatriculaID INT FOREIGN KEY REFERENCES Matriculas(MatriculaID),
            Calificacion DECIMAL(4,2) CHECK(Calificacion BETWEEN 0 AND 5)
        )
    END
END;
GO
EXEC sp_crear_tabla_notas;
GO

CREATE PROCEDURE sp_crear_tabla_bibliotecas
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Bibliotecas' AND xtype='U')
    BEGIN
        CREATE TABLE Bibliotecas (
            BibliotecaID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(100) NOT NULL,
            Ubicacion VARCHAR(100) NOT NULL
        )
    END
END;
GO
EXEC sp_crear_tabla_bibliotecas;
GO


CREATE PROCEDURE sp_insertar_estudiante
    @Nombre VARCHAR(50),
    @Apellido VARCHAR(50),
    @Email VARCHAR(100),
    @FechaNacimiento DATE,
    @ProgramaID INT = NULL
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Estudiantes WHERE Email = @Email)
    BEGIN
        PRINT 'El estudiante ya está registrado con ese email.';
        RETURN;
    END
    INSERT INTO Estudiantes (Nombre, Apellido, Email, FechaNacimiento, ProgramaID)
    VALUES (@Nombre, @Apellido, @Email, @FechaNacimiento, @ProgramaID)
END;
GO


CREATE PROCEDURE sp_insertar_profesor
    @Nombre VARCHAR(50),
    @Apellido VARCHAR(50),
    @Especialidad VARCHAR(50),
    @Email VARCHAR(100)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Profesores WHERE Email = @Email)
    BEGIN
        PRINT 'Profesor ya registrado con ese email.';
        RETURN;
    END
    INSERT INTO Profesores (Nombre, Apellido, Especialidad, Email)
    VALUES (@Nombre, @Apellido, @Especialidad, @Email)
END;
GO

/
CREATE PROCEDURE sp_insertar_curso
    @Nombre VARCHAR(100),
    @Creditos INT,
    @ProfesorID INT
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Profesores WHERE ProfesorID = @ProfesorID)
    BEGIN
        PRINT 'Profesor no existe.';
        RETURN;
    END
    INSERT INTO Cursos (Nombre, Creditos, ProfesorID)
    VALUES (@Nombre, @Creditos, @ProfesorID)
END;
GO


CREATE PROCEDURE sp_insertar_programa
    @Nombre VARCHAR(100),
    @Facultad VARCHAR(100)
AS
BEGIN
    INSERT INTO Programas (Nombre, Facultad) VALUES (@Nombre, @Facultad)
END;
GO


CREATE PROCEDURE sp_insertar_matricula
    @EstudianteID INT,
    @CursoID INT
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Estudiantes WHERE EstudianteID = @EstudianteID)
    BEGIN
        PRINT 'Estudiante no existe.';
        RETURN;
    END
    IF NOT EXISTS (SELECT 1 FROM Cursos WHERE CursoID = @CursoID)
    BEGIN
        PRINT 'Curso no existe.';
        RETURN;
    END
    INSERT INTO Matriculas (EstudianteID, CursoID)
    VALUES (@EstudianteID, @CursoID)
END;
GO


CREATE PROCEDURE sp_insertar_nota
    @MatriculaID INT,
    @Calificacion DECIMAL(4,2)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Matriculas WHERE MatriculaID = @MatriculaID)
    BEGIN
        PRINT 'Matrícula no existe.';
        RETURN;
    END
    INSERT INTO Notas (MatriculaID, Calificacion)
    VALUES (@MatriculaID, @Calificacion)
END;
GO


CREATE PROCEDURE sp_insertar_biblioteca
    @Nombre VARCHAR(100),
    @Ubicacion VARCHAR(100)
AS
BEGIN
    INSERT INTO Bibliotecas (Nombre, Ubicacion)
    VALUES (@Nombre, @Ubicacion)
END;
GO


EXEC sp_insertar_programa 'Ingeniería de Sistemas','Facultad de Ingeniería';
EXEC sp_insertar_programa 'Derecho','Facultad de Ciencias Jurídicas';
EXEC sp_insertar_programa 'Medicina','Facultad de Ciencias de la Salud';
EXEC sp_insertar_programa 'Administración de Empresas','Facultad de Economía';
EXEC sp_insertar_programa 'Psicología','Facultad de Ciencias Sociales';
EXEC sp_insertar_programa 'Arquitectura','Facultad de Arquitectura';
EXEC sp_insertar_programa 'Contaduría Pública','Facultad de Economía';
EXEC sp_insertar_programa 'Ingeniería Civil','Facultad de Ingeniería';
EXEC sp_insertar_programa 'Enfermería','Facultad de Ciencias de la Salud';
EXEC sp_insertar_programa 'Comunicación Social','Facultad de Humanidades';


EXEC sp_insertar_estudiante 'Juan','Pérez','juanp@uni.edu','2000-05-10',1;
EXEC sp_insertar_estudiante 'Ana','Martínez','anam@uni.edu','2001-03-22',2;
EXEC sp_insertar_estudiante 'Luis','Gómez','luisg@uni.edu','1999-11-15',1;
EXEC sp_insertar_estudiante 'María','López','marial@uni.edu','2002-01-30',3;
EXEC sp_insertar_estudiante 'Pedro','Ramírez','pedror@uni.edu','2000-07-19',4;
EXEC sp_insertar_estudiante 'Lucía','Fernández','luciaf@uni.edu','1998-09-25',5;
EXEC sp_insertar_estudiante 'Carlos','Torres','carlost@uni.edu','2001-12-12',6;
EXEC sp_insertar_estudiante 'Laura','Hernández','laurah@uni.edu','2000-04-05',7;
EXEC sp_insertar_estudiante 'Diego','Castro','diegoc@uni.edu','1999-06-17',8;
EXEC sp_insertar_estudiante 'Paola','Jiménez','paolaj@uni.edu','2002-02-28',9;


EXEC sp_insertar_profesor 'Andrés','Santos','Programación','andres@uni.edu';
EXEC sp_insertar_profesor 'Beatriz','Mora','Derecho Penal','beatriz@uni.edu';
EXEC sp_insertar_profesor 'Camilo','Pardo','Cirugía','camilo@uni.edu';
EXEC sp_insertar_profesor 'Daniela','Vargas','Administración','daniela@uni.edu';
EXEC sp_insertar_profesor 'Esteban','Suárez','Psicología Clínica','esteban@uni.edu';
EXEC sp_insertar_profesor 'Felipe','López','Diseño Urbano','felipe@uni.edu';
EXEC sp_insertar_profesor 'Gabriela','Moreno','Contabilidad','gabriela@uni.edu';
EXEC sp_insertar_profesor 'Héctor','Silva','Estructuras','hector@uni.edu';
EXEC sp_insertar_profesor 'Isabel','Cruz','Enfermería General','isabel@uni.edu';
EXEC sp_insertar_profesor 'Jorge','Castillo','Periodismo','jorge@uni.edu';


EXEC sp_insertar_curso 'Programación I',4,1;
EXEC sp_insertar_curso 'Derecho Constitucional',3,2;
EXEC sp_insertar_curso 'Anatomía Humana',5,3;
EXEC sp_insertar_curso 'Teoría Administrativa',4,4;
EXEC sp_insertar_curso 'Psicología del Desarrollo',3,5;
EXEC sp_insertar_curso 'Diseño Arquitectónico',4,6;
EXEC sp_insertar_curso 'Contabilidad Financiera',4,7;
EXEC sp_insertar_curso 'Mecánica de Suelos',5,8;
EXEC sp_insertar_curso 'Cuidado del Paciente',3,9;
EXEC sp_insertar_curso 'Redacción Periodística',2,10;


EXEC sp_insertar_biblioteca 'Biblioteca Central','Bloque A';
EXEC sp_insertar_biblioteca 'Biblioteca Jurídica','Bloque B';
EXEC sp_insertar_biblioteca 'Biblioteca Ciencias de la Salud','Bloque C';
EXEC sp_insertar_biblioteca 'Biblioteca Ingeniería','Bloque D';
EXEC sp_insertar_biblioteca 'Biblioteca Economía','Bloque E';
EXEC sp_insertar_biblioteca 'Biblioteca Humanidades','Bloque F';
EXEC sp_insertar_biblioteca 'Biblioteca Psicología','Bloque G';
EXEC sp_insertar_biblioteca 'Biblioteca Arquitectura','Bloque H';
EXEC sp_insertar_biblioteca 'Biblioteca Ciencias Sociales','Bloque I';
EXEC sp_insertar_biblioteca 'Biblioteca Comunicación','Bloque J';


EXEC sp_insertar_matricula 1,1;
EXEC sp_insertar_matricula 2,2;
EXEC sp_insertar_matricula 3,3;
EXEC sp_insertar_matricula 4,4;
EXEC sp_insertar_matricula 5,5;
EXEC sp_insertar_matricula 6,6;
EXEC sp_insertar_matricula 7,7;
EXEC sp_insertar_matricula 8,8;
EXEC sp_insertar_matricula 9,9;
EXEC sp_insertar_matricula 10,10;


EXEC sp_insertar_nota 1,4.5;
EXEC sp_insertar_nota 2,3.8;
EXEC sp_insertar_nota 3,4.2;
EXEC sp_insertar_nota 4,3.5;
EXEC sp_insertar_nota 5,4.7;
EXEC sp_insertar_nota 6,3.9;
EXEC sp_insertar_nota 7,4.1;
EXEC sp_insertar_nota 8,2.8;
EXEC sp_insertar_nota 9,4.0;
EXEC sp_insertar_nota 10,3.6;


CREATE VIEW vw_estudiantes_programas AS
SELECT e.Nombre, e.Apellido, p.Nombre AS Programa, p.Facultad
FROM Estudiantes e
JOIN Programas p ON e.ProgramaID = p.ProgramaID;
GO


CREATE VIEW vw_promedio_notas_estudiante AS
SELECT e.Nombre, e.Apellido, AVG(n.Calificacion) AS Promedio
FROM Estudiantes e
JOIN Matriculas m ON e.EstudianteID = m.EstudianteID
JOIN Notas n ON m.MatriculaID = n.MatriculaID
GROUP BY e.Nombre, e.Apellido;
GO


CREATE VIEW vw_cursos_matriculados AS
SELECT c.Nombre AS Curso, COUNT(m.MatriculaID) AS TotalMatriculados
FROM Cursos c
LEFT JOIN Matriculas m ON c.CursoID = m.CursoID
GROUP BY c.Nombre;
GO


CREATE VIEW vw_profesores_cursos AS
SELECT p.Nombre, p.Apellido, c.Nombre AS Curso
FROM Profesores p
JOIN Cursos c ON p.ProfesorID = c.ProfesorID;
GO


CREATE VIEW vw_estudiantes_bajo_rendimiento AS
SELECT e.Nombre, e.Apellido, n.Calificacion
FROM Estudiantes e
JOIN Matriculas m ON e.EstudianteID = m.EstudianteID
JOIN Notas n ON m.MatriculaID = n.MatriculaID
WHERE n.Calificacion < 3;
GO
