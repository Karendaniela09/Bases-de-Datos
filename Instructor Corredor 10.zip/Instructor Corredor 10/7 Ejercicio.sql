
CREATE DATABASE Hotel;
GO
USE Hotel;
GO


CREATE PROCEDURE sp_crear_tabla_clientes
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Clientes' AND xtype='U')
    BEGIN
        CREATE TABLE Clientes (
            ClienteID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Apellido VARCHAR(50) NOT NULL,
            Telefono VARCHAR(20),
            Email VARCHAR(100) UNIQUE,
            FechaRegistro DATE DEFAULT GETDATE()
        )
    END
END;
GO
EXEC sp_crear_tabla_clientes;
GO


CREATE PROCEDURE sp_crear_tabla_habitaciones
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Habitaciones' AND xtype='U')
    BEGIN
        CREATE TABLE Habitaciones (
            HabitacionID INT PRIMARY KEY IDENTITY,
            NumeroHabitacion INT UNIQUE NOT NULL,
            Tipo VARCHAR(50),
            Precio DECIMAL(10,2) CHECK (Precio > 0),
            Estado VARCHAR(20) DEFAULT 'Disponible'
        )
    END
END;
GO
EXEC sp_crear_tabla_habitaciones;
GO


CREATE PROCEDURE sp_crear_tabla_empleados
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Empleados' AND xtype='U')
    BEGIN
        CREATE TABLE Empleados (
            EmpleadoID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Apellido VARCHAR(50) NOT NULL,
            Cargo VARCHAR(50),
            Telefono VARCHAR(20),
            Email VARCHAR(100) UNIQUE
        )
    END
END;
GO
EXEC sp_crear_tabla_empleados;
GO


CREATE PROCEDURE sp_crear_tabla_reservas
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Reservas' AND xtype='U')
    BEGIN
        CREATE TABLE Reservas (
            ReservaID INT PRIMARY KEY IDENTITY,
            ClienteID INT FOREIGN KEY REFERENCES Clientes(ClienteID),
            HabitacionID INT FOREIGN KEY REFERENCES Habitaciones(HabitacionID),
            FechaEntrada DATE NOT NULL,
            FechaSalida DATE NOT NULL,
            Estado VARCHAR(20) DEFAULT 'Activa'
        )
    END
END;
GO
EXEC sp_crear_tabla_reservas;
GO

CREATE PROCEDURE sp_crear_tabla_facturas
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Facturas' AND xtype='U')
    BEGIN
        CREATE TABLE Facturas (
            FacturaID INT PRIMARY KEY IDENTITY,
            ReservaID INT FOREIGN KEY REFERENCES Reservas(ReservaID),
            FechaFactura DATE DEFAULT GETDATE(),
            Total DECIMAL(10,2) CHECK (Total >= 0)
        )
    END
END;
GO
EXEC sp_crear_tabla_facturas;
GO


CREATE PROCEDURE sp_crear_tabla_servicios
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Servicios' AND xtype='U')
    BEGIN
        CREATE TABLE Servicios (
            ServicioID INT PRIMARY KEY IDENTITY,
            NombreServicio VARCHAR(100),
            Precio DECIMAL(10,2) CHECK (Precio > 0)
        )
    END
END;
GO
EXEC sp_crear_tabla_servicios;
GO


CREATE PROCEDURE sp_crear_tabla_detalleservicios
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='DetalleServicios' AND xtype='U')
    BEGIN
        CREATE TABLE DetalleServicios (
            DetalleID INT PRIMARY KEY IDENTITY,
            FacturaID INT FOREIGN KEY REFERENCES Facturas(FacturaID),
            ServicioID INT FOREIGN KEY REFERENCES Servicios(ServicioID),
            Cantidad INT CHECK (Cantidad > 0),
            Subtotal DECIMAL(10,2) CHECK (Subtotal >= 0)
        )
    END
END;
GO
EXEC sp_crear_tabla_detalleservicios;
GO


CREATE PROCEDURE sp_insertar_cliente
    @Nombre VARCHAR(50),
    @Apellido VARCHAR(50),
    @Telefono VARCHAR(20),
    @Email VARCHAR(100)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Clientes WHERE Email=@Email)
    BEGIN
        PRINT ' Cliente ya existe';
        RETURN;
    END
    INSERT INTO Clientes (Nombre,Apellido,Telefono,Email) VALUES (@Nombre,@Apellido,@Telefono,@Email);
END;
GO


EXEC sp_insertar_cliente 'Carlos','Ramírez','3101111111','carlos@hotel.com';
EXEC sp_insertar_cliente 'Ana','Martínez','3102222222','ana@hotel.com';
EXEC sp_insertar_cliente 'Diego','Hernández','3103333333','diego@hotel.com';
EXEC sp_insertar_cliente 'Laura','López','3104444444','laura@hotel.com';
EXEC sp_insertar_cliente 'Felipe','Castro','3105555555','felipe@hotel.com';
EXEC sp_insertar_cliente 'Valentina','Morales','3106666666','valentina@hotel.com';
EXEC sp_insertar_cliente 'Jorge','Pérez','3107777777','jorge@hotel.com';
EXEC sp_insertar_cliente 'Camila','Suárez','3108888888','camila@hotel.com';
EXEC sp_insertar_cliente 'Sofía','Gómez','3109999999','sofia@hotel.com';
EXEC sp_insertar_cliente 'Andrés','Torres','3110000000','andres@hotel.com';


CREATE PROCEDURE sp_insertar_habitacion
    @NumeroHabitacion INT,
    @Tipo VARCHAR(50),
    @Precio DECIMAL(10,2),
    @Estado VARCHAR(20)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Habitaciones WHERE NumeroHabitacion=@NumeroHabitacion)
    BEGIN
        PRINT ' Habitación ya existe';
        RETURN;
    END
    INSERT INTO Habitaciones (NumeroHabitacion,Tipo,Precio,Estado) VALUES (@NumeroHabitacion,@Tipo,@Precio,@Estado);
END;
GO


EXEC sp_insertar_habitacion 101,'Sencilla',120000,'Disponible';
EXEC sp_insertar_habitacion 102,'Doble',180000,'Disponible';
EXEC sp_insertar_habitacion 103,'Suite',350000,'Disponible';
EXEC sp_insertar_habitacion 104,'Sencilla',120000,'Disponible';
EXEC sp_insertar_habitacion 105,'Doble',180000,'Disponible';
EXEC sp_insertar_habitacion 106,'Suite',350000,'Disponible';
EXEC sp_insertar_habitacion 107,'Sencilla',120000,'Disponible';
EXEC sp_insertar_habitacion 108,'Doble',180000,'Disponible';
EXEC sp_insertar_habitacion 109,'Suite',350000,'Disponible';
EXEC sp_insertar_habitacion 110,'Sencilla',120000,'Disponible';


CREATE PROCEDURE sp_insertar_empleado
    @Nombre VARCHAR(50),
    @Apellido VARCHAR(50),
    @Cargo VARCHAR(50),
    @Telefono VARCHAR(20),
    @Email VARCHAR(100)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Empleados WHERE Email=@Email)
    BEGIN
        PRINT ' Empleado ya existe';
        RETURN;
    END
    INSERT INTO Empleados (Nombre,Apellido,Cargo,Telefono,Email) VALUES (@Nombre,@Apellido,@Cargo,@Telefono,@Email);
END;
GO

EXEC sp_insertar_empleado 'Luis','Mendoza','Recepcionista','3001111111','luis@hotel.com';
EXEC sp_insertar_empleado 'Paula','Gómez','Camarera','3002222222','paula@hotel.com';
EXEC sp_insertar_empleado 'Jorge','López','Administrador','3003333333','jorge@hotel.com';
EXEC sp_insertar_empleado 'Carolina','Ríos','Cocinera','3004444444','caro@hotel.com';
EXEC sp_insertar_empleado 'Andrés','Martínez','Botones','3005555555','andres@hotel.com';
EXEC sp_insertar_empleado 'Natalia','Castro','Mesera','3006666666','natalia@hotel.com';
EXEC sp_insertar_empleado 'Felipe','Suárez','Seguridad','3007777777','felipe@hotel.com';
EXEC sp_insertar_empleado 'Valeria','Ramírez','Recepcionista','3008888888','valeria@hotel.com';
EXEC sp_insertar_empleado 'Camilo','Torres','Botones','3009999999','camilo@hotel.com';
EXEC sp_insertar_empleado 'Mariana','Ortiz','Gerente','3010000000','mariana@hotel.com');

CREATE PROCEDURE sp_insertar_servicio
    @NombreServicio VARCHAR(100),
    @Precio DECIMAL(10,2)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Servicios WHERE NombreServicio=@NombreServicio)
    BEGIN
        PRINT ' Servicio ya existe';
        RETURN;
    END
    INSERT INTO Servicios (NombreServicio,Precio) VALUES (@NombreServicio,@Precio);
END;
GO


EXEC sp_insertar_servicio 'Desayuno',20000;
EXEC sp_insertar_servicio 'Almuerzo',35000;
EXEC sp_insertar_servicio 'Cena',40000;
EXEC sp_insertar_servicio 'Spa',80000;
EXEC sp_insertar_servicio 'Gimnasio',15000;
EXEC sp_insertar_servicio 'Piscina',10000;
EXEC sp_insertar_servicio 'Transporte Aeropuerto',60000;
EXEC sp_insertar_servicio 'Lavandería',25000;
EXEC sp_insertar_servicio 'Bar',30000;
EXEC sp_insertar_servicio 'Tour Turístico',120000;


CREATE VIEW vw_reservas_cliente AS
SELECT c.Nombre,c.Apellido,h.NumeroHabitacion,h.Tipo,r.FechaEntrada,r.FechaSalida
FROM Reservas r
JOIN Clientes c ON r.ClienteID=c.ClienteID
JOIN Habitaciones h ON r.HabitacionID=h.HabitacionID
WHERE r.Estado='Activa';

CREATE VIEW vw_habitaciones_ocupadas AS
SELECT NumeroHabitacion,Tipo,Estado
FROM Habitaciones
WHERE Estado='Ocupada';


CREATE VIEW vw_facturacion_cliente AS
SELECT c.Nombre,c.Apellido,SUM(f.Total) AS TotalGastado
FROM Facturas f
JOIN Reservas r ON f.ReservaID=r.ReservaID
JOIN Clientes c ON r.ClienteID=c.ClienteID
GROUP BY c.Nombre,c.Apellido;


CREATE VIEW vw_servicios_mas_solicitados AS
SELECT s.NombreServicio,SUM(d.Cantidad) AS TotalSolicitado
FROM DetalleServicios d
JOIN Servicios s ON d.ServicioID=s.ServicioID
GROUP BY s.NombreServicio
ORDER BY TotalSolicitado DESC;


CREATE VIEW vw_empleados_cargo AS
SELECT Cargo,COUNT(*) AS NumEmpleados
FROM Empleados
GROUP BY Cargo;

