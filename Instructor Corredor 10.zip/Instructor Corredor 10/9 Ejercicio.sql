
CREATE DATABASE Jugueteria;
GO
USE Jugueteria;
GO


CREATE PROCEDURE sp_crear_tabla_clientes
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Clientes' AND xtype='U')
    BEGIN
        CREATE TABLE Clientes (
            ClienteID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Apellido VARCHAR(50) NOT NULL,
            Telefono VARCHAR(20),
            Email VARCHAR(100) UNIQUE
        );
    END
END;
GO
EXEC sp_crear_tabla_clientes;


CREATE PROCEDURE sp_crear_tabla_proveedores
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Proveedores' AND xtype='U')
    BEGIN
        CREATE TABLE Proveedores (
            ProveedorID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(100) NOT NULL,
            Telefono VARCHAR(20),
            Direccion VARCHAR(100),
            Email VARCHAR(100) UNIQUE
        );
    END
END;
GO
EXEC sp_crear_tabla_proveedores;


CREATE PROCEDURE sp_crear_tabla_categorias
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Categorias' AND xtype='U')
    BEGIN
        CREATE TABLE Categorias (
            CategoriaID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Descripcion VARCHAR(100)
        );
    END
END;
GO
EXEC sp_crear_tabla_categorias;


CREATE PROCEDURE sp_crear_tabla_juguetes
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Juguetes' AND xtype='U')
    BEGIN
        CREATE TABLE Juguetes (
            JugueteID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(100) NOT NULL,
            Precio DECIMAL(10,2) CHECK(Precio > 0),
            Stock INT CHECK(Stock >= 0),
            CategoriaID INT FOREIGN KEY REFERENCES Categorias(CategoriaID),
            ProveedorID INT FOREIGN KEY REFERENCES Proveedores(ProveedorID)
        );
    END
END;
GO
EXEC sp_crear_tabla_juguetes;

CREATE PROCEDURE sp_crear_tabla_empleados
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Empleados' AND xtype='U')
    BEGIN
        CREATE TABLE Empleados (
            EmpleadoID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Apellido VARCHAR(50) NOT NULL,
            Cargo VARCHAR(50),
            Telefono VARCHAR(20)
        );
    END
END;
GO
EXEC sp_crear_tabla_empleados;


CREATE PROCEDURE sp_crear_tabla_ventas
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Ventas' AND xtype='U')
    BEGIN
        CREATE TABLE Ventas (
            VentaID INT PRIMARY KEY IDENTITY,
            ClienteID INT FOREIGN KEY REFERENCES Clientes(ClienteID),
            EmpleadoID INT FOREIGN KEY REFERENCES Empleados(EmpleadoID),
            Fecha DATE DEFAULT GETDATE(),
            Total DECIMAL(10,2) CHECK(Total >= 0)
        );
    END
END;
GO
EXEC sp_crear_tabla_ventas;

CREATE PROCEDURE sp_crear_tabla_detalleventas
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='DetalleVentas' AND xtype='U')
    BEGIN
        CREATE TABLE DetalleVentas (
            DetalleID INT PRIMARY KEY IDENTITY,
            VentaID INT FOREIGN KEY REFERENCES Ventas(VentaID),
            JugueteID INT FOREIGN KEY REFERENCES Juguetes(JugueteID),
            Cantidad INT CHECK(Cantidad > 0),
            PrecioUnitario DECIMAL(10,2) CHECK(PrecioUnitario > 0)
        );
    END
END;
GO
EXEC sp_crear_tabla_detalleventas;


INSERT INTO Clientes (Nombre,Apellido,Telefono,Email) VALUES
('Carlos','Gómez','3101234567','carlos@gmail.com'),
('María','López','3112345678','maria@gmail.com'),
('Juan','Martínez','3123456789','juan@gmail.com'),
('Ana','Rodríguez','3134567890','ana@gmail.com'),
('Pedro','Sánchez','3145678901','pedro@gmail.com'),
('Laura','Torres','3156789012','laura@gmail.com'),
('Andrés','Ramírez','3167890123','andres@gmail.com'),
('Sofía','Morales','3178901234','sofia@gmail.com'),
('Diego','Castro','3189012345','diego@gmail.com'),
('Camila','Hernández','3190123456','camila@gmail.com');


INSERT INTO Proveedores (Nombre,Telefono,Direccion,Email) VALUES
('Juguetes S.A.','3201111111','Cra 10 # 20-30','prove1@gmail.com'),
('Diversión Ltda','3202222222','Calle 15 # 5-25','prove2@gmail.com'),
('Mundo Infantil','3203333333','Cra 45 # 12-50','prove3@gmail.com'),
('Diversión Express','3204444444','Av 30 # 45-60','prove4@gmail.com'),
('Magic Toys','3205555555','Cra 25 # 7-15','prove5@gmail.com'),
('Happy Kids','3206666666','Calle 8 # 12-40','prove6@gmail.com'),
('ToyMarket','3207777777','Av 68 # 40-90','prove7@gmail.com'),
('Super Juguetes','3208888888','Cra 80 # 20-10','prove8@gmail.com'),
('Baby World','3209999999','Calle 70 # 13-22','prove9@gmail.com'),
('Kids Planet','3210000000','Cra 60 # 14-55','prove10@gmail.com');


INSERT INTO Categorias (Nombre,Descripcion) VALUES
('Muñecas','Muñecas, accesorios'),
('Carros','Autos de juguete'),
('Educativos','Juegos de aprendizaje'),
('Deportes','Balones, raquetas'),
('Electrónicos','Consolas, robots'),
('Construcción','Bloques, legos'),
('Peluches','Animales de felpa'),
('Exterior','Juguetes para parque'),
('Mesa','Juegos de mesa'),
('Otros','Varios');


INSERT INTO Empleados (Nombre,Apellido,Cargo,Telefono) VALUES
('Lucía','Mendoza','Cajera','3221111111'),
('Andrés','Vargas','Vendedor','3222222222'),
('Carolina','Reyes','Gerente','3223333333'),
('Felipe','Ortiz','Vendedor','3224444444'),
('Juliana','Moreno','Auxiliar','3225555555'),
('Hernán','Silva','Bodeguero','3226666666'),
('Daniela','Guzmán','Cajera','3227777777'),
('Sergio','Pérez','Vendedor','3228888888'),
('Natalia','Ríos','Auxiliar','3229999999'),
('Camilo','Suárez','Administrador','3230000000');


INSERT INTO Juguetes (Nombre,Precio,Stock,CategoriaID,ProveedorID) VALUES
('Muñeca Barbie',45000,100,1,1),
('Carro Hot Wheels',15000,200,2,2),
('Rompecabezas 100 piezas',20000,80,3,3),
('Balón de fútbol',30000,50,4,4),
('Robot interactivo',80000,30,5,5),
('Caja de Legos',60000,40,6,6),
('Oso de Peluche',25000,70,7,7),
('Trampolín pequeño',120000,20,8,8),
('Ajedrez clásico',35000,60,9,9),
('Set de cocina',40000,90,10,10);


INSERT INTO Ventas (ClienteID,EmpleadoID,Fecha,Total) VALUES
(1,1,'2025-09-01',90000),
(2,2,'2025-09-02',150000),
(3,3,'2025-09-03',60000),
(4,4,'2025-09-04',80000),
(5,5,'2025-09-05',50000),
(6,6,'2025-09-06',120000),
(7,7,'2025-09-07',70000),
(8,8,'2025-09-08',110000),
(9,9,'2025-09-09',45000),
(10,10,'2025-09-10',130000);


INSERT INTO DetalleVentas (VentaID,JugueteID,Cantidad,PrecioUnitario) VALUES
(1,1,2,45000),
(2,2,10,15000),
(3,3,3,20000),
(4,4,2,30000),
(5,5,1,80000),
(6,6,2,60000),
(7,7,4,25000),
(8,8,1,120000),
(9,9,1,35000),
(10,10,2,40000);

CREATE VIEW vw_total_ventas_cliente AS
SELECT c.Nombre, c.Apellido, SUM(v.Total) AS TotalGastado
FROM Clientes c
JOIN Ventas v ON c.ClienteID = v.ClienteID
GROUP BY c.Nombre, c.Apellido;

CREATE VIEW vw_juguetes_mas_vendidos AS
SELECT j.Nombre, SUM(d.Cantidad) AS CantidadVendida
FROM DetalleVentas d
JOIN Juguetes j ON d.JugueteID = j.JugueteID
GROUP BY j.Nombre
ORDER BY CantidadVendida DES
CREATE VIEW vw_ventas_por_empleado AS
SELECT e.Nombre, e.Apellido, SUM(v.Total) AS TotalVendido
FROM Ventas v
JOIN Empleados e ON v.EmpleadoID = e.EmpleadoID
GROUP BY e.Nombre, e.Apellido;


CREATE VIEW vw_stock_bajo AS
SELECT Nombre, Stock, Precio
FROM Juguetes
WHERE Stock < 50;

CREATE VIEW vw_clientes_frecuentes AS
SELECT c.Nombre, c.Apellido, COUNT(v.VentaID) AS Compras
FROM Ventas v
JOIN Clientes c ON v.ClienteID = c.ClienteID
GROUP BY c.Nombre, c.Apellido
ORDER BY Compras DESC;
