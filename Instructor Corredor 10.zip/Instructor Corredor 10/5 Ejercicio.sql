
CREATE DATABASE Restaurante;
GO
USE Restaurante;
GO


CREATE PROCEDURE sp_crear_tabla_clientes
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Clientes' AND xtype='U')
    BEGIN
        CREATE TABLE Clientes (
            ClienteID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Telefono VARCHAR(20) UNIQUE,
            Email VARCHAR(100) UNIQUE
        )
    END
END;
GO
EXEC sp_crear_tabla_clientes;


CREATE PROCEDURE sp_crear_tabla_mesas
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Mesas' AND xtype='U')
    BEGIN
        CREATE TABLE Mesas (
            MesaID INT PRIMARY KEY IDENTITY,
            Numero INT UNIQUE NOT NULL,
            Capacidad INT CHECK (Capacidad > 0)
        )
    END
END;
GO
EXEC sp_crear_tabla_mesas;


CREATE PROCEDURE sp_crear_tabla_reservas
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Reservas' AND xtype='U')
    BEGIN
        CREATE TABLE Reservas (
            ReservaID INT PRIMARY KEY IDENTITY,
            ClienteID INT FOREIGN KEY REFERENCES Clientes(ClienteID),
            MesaID INT FOREIGN KEY REFERENCES Mesas(MesaID),
            FechaReserva DATETIME NOT NULL
        )
    END
END;
GO
EXEC sp_crear_tabla_reservas;


CREATE PROCEDURE sp_crear_tabla_empleados
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Empleados' AND xtype='U')
    BEGIN
        CREATE TABLE Empleados (
            EmpleadoID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Cargo VARCHAR(30) NOT NULL
        )
    END
END;
GO
EXEC sp_crear_tabla_empleados;


CREATE PROCEDURE sp_crear_tabla_menu
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Menu' AND xtype='U')
    BEGIN
        CREATE TABLE Menu (
            PlatoID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(100) NOT NULL,
            Precio DECIMAL(10,2) CHECK (Precio > 0)
        )
    END
END;
GO
EXEC sp_crear_tabla_menu;


CREATE PROCEDURE sp_crear_tabla_pedidos
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Pedidos' AND xtype='U')
    BEGIN
        CREATE TABLE Pedidos (
            PedidoID INT PRIMARY KEY IDENTITY,
            ClienteID INT FOREIGN KEY REFERENCES Clientes(ClienteID),
            EmpleadoID INT FOREIGN KEY REFERENCES Empleados(EmpleadoID),
            FechaPedido DATE NOT NULL
        )
    END
END;
GO
EXEC sp_crear_tabla_pedidos;

CREATE PROCEDURE sp_crear_tabla_facturas
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Facturas' AND xtype='U')
    BEGIN
        CREATE TABLE Facturas (
            FacturaID INT PRIMARY KEY IDENTITY,
            PedidoID INT FOREIGN KEY REFERENCES Pedidos(PedidoID),
            Total DECIMAL(10,2) CHECK (Total > 0),
            Fecha DATE NOT NULL
        )
    END
END;
GO
EXEC sp_crear_tabla_facturas;


CREATE PROCEDURE sp_insertar_cliente
    @Nombre VARCHAR(50),
    @Telefono VARCHAR(20),
    @Email VARCHAR(100)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Clientes WHERE Telefono = @Telefono OR Email = @Email)
    BEGIN
        PRINT 'El cliente ya existe';
        RETURN;
    END
    INSERT INTO Clientes (Nombre, Telefono, Email)
    VALUES (@Nombre, @Telefono, @Email);
END;
GO


CREATE PROCEDURE sp_insertar_mesa
    @Numero INT,
    @Capacidad INT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Mesas WHERE Numero = @Numero)
    BEGIN
        PRINT 'La mesa ya existe';
        RETURN;
    END
    INSERT INTO Mesas (Numero, Capacidad)
    VALUES (@Numero, @Capacidad);
END;
GO


CREATE PROCEDURE sp_insertar_reserva
    @ClienteID INT,
    @MesaID INT,
    @FechaReserva DATETIME
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Clientes WHERE ClienteID = @ClienteID)
    BEGIN
        PRINT 'Cliente no existe';
        RETURN;
    END
    IF NOT EXISTS (SELECT 1 FROM Mesas WHERE MesaID = @MesaID)
    BEGIN
        PRINT 'Mesa no existe';
        RETURN;
    END
    INSERT INTO Reservas (ClienteID, MesaID, FechaReserva)
    VALUES (@ClienteID, @MesaID, @FechaReserva);
END;
GO


CREATE PROCEDURE sp_insertar_empleado
    @Nombre VARCHAR(50),
    @Cargo VARCHAR(30)
AS
BEGIN
    IF (@Nombre = '' OR @Cargo = '')
    BEGIN
        PRINT 'Nombre y Cargo obligatorios';
        RETURN;
    END
    INSERT INTO Empleados (Nombre, Cargo)
    VALUES (@Nombre, @Cargo);
END;
GO


CREATE PROCEDURE sp_insertar_plato
    @Nombre VARCHAR(100),
    @Precio DECIMAL(10,2)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Menu WHERE Nombre = @Nombre)
    BEGIN
        PRINT 'El plato ya existe';
        RETURN;
    END
    INSERT INTO Menu (Nombre, Precio)
    VALUES (@Nombre, @Precio);
END;
GO


CREATE PROCEDURE sp_insertar_pedido
    @ClienteID INT,
    @EmpleadoID INT,
    @FechaPedido DATE
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Clientes WHERE ClienteID = @ClienteID)
    BEGIN
        PRINT 'Cliente no existe';
        RETURN;
    END
    IF NOT EXISTS (SELECT 1 FROM Empleados WHERE EmpleadoID = @EmpleadoID)
    BEGIN
        PRINT 'Empleado no existe';
        RETURN;
    END
    INSERT INTO Pedidos (ClienteID, EmpleadoID, FechaPedido)
    VALUES (@ClienteID, @EmpleadoID, @FechaPedido);
END;
GO


CREATE PROCEDURE sp_insertar_factura
    @PedidoID INT,
    @Total DECIMAL(10,2),
    @Fecha DATE
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Pedidos WHERE PedidoID = @PedidoID)
    BEGIN
        PRINT 'Pedido no existe';
        RETURN;
    END
    IF (@Total <= 0)
    BEGIN
        PRINT 'El total debe ser positivo';
        RETURN;
    END
    INSERT INTO Facturas (PedidoID, Total, Fecha)
    VALUES (@PedidoID, @Total, @Fecha);
END;
GO


CREATE VIEW vw_reservas_clientes AS
SELECT c.Nombre, m.Numero AS Mesa, r.FechaReserva
FROM Reservas r
JOIN Clientes c ON r.ClienteID = c.ClienteID
JOIN Mesas m ON r.MesaID = m.MesaID;
GO


CREATE VIEW vw_pedidos_empleados AS
SELECT e.Nombre AS Empleado, e.Cargo, COUNT(p.PedidoID) AS TotalPedidos
FROM Empleados e
LEFT JOIN Pedidos p ON e.EmpleadoID = p.EmpleadoID
GROUP BY e.Nombre, e.Cargo;
GO


CREATE VIEW vw_facturacion_diaria AS
SELECT Fecha, SUM(Total) AS TotalFacturado
FROM Facturas
GROUP BY Fecha;
GO

CREATE VIEW vw_clientes_frecuentes AS
SELECT c.Nombre, COUNT(p.PedidoID) AS NumeroPedidos
FROM Clientes c
JOIN Pedidos p ON c.ClienteID = p.ClienteID
GROUP BY c.Nombre
HAVING COUNT(p.PedidoID) > 1;
GO

CREATE VIEW vw_platos_caros AS
SELECT Nombre, Precio
FROM Menu
WHERE Precio > 30000;
GO
