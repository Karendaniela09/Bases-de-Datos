
CREATE DATABASE TiendaOnline;
GO
USE TiendaOnline;
GO

CREATE PROCEDURE sp_crear_tabla_usuarios
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Usuarios' AND xtype='U')
    BEGIN
        CREATE TABLE Usuarios (
            UsuarioID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Email VARCHAR(100) UNIQUE NOT NULL,
            Contraseña VARCHAR(100) NOT NULL,
            FechaRegistro DATE DEFAULT GETDATE()
        )
    END
END;
GO
EXEC sp_crear_tabla_usuarios;


CREATE PROCEDURE sp_crear_tabla_categorias
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Categorias' AND xtype='U')
    BEGIN
        CREATE TABLE Categorias (
            CategoriaID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL
        )
    END
END;
GO
EXEC sp_crear_tabla_categorias;


CREATE PROCEDURE sp_crear_tabla_productos
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Productos' AND xtype='U')
    BEGIN
        CREATE TABLE Productos (
            ProductoID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(100) NOT NULL,
            Precio DECIMAL(10,2) CHECK (Precio > 0),
            Stock INT CHECK (Stock >= 0),
            CategoriaID INT FOREIGN KEY REFERENCES Categorias(CategoriaID)
        )
    END
END;
GO
EXEC sp_crear_tabla_productos;


CREATE PROCEDURE sp_crear_tabla_carritos
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Carritos' AND xtype='U')
    BEGIN
        CREATE TABLE Carritos (
            CarritoID INT PRIMARY KEY IDENTITY,
            UsuarioID INT FOREIGN KEY REFERENCES Usuarios(UsuarioID),
            FechaCreacion DATE DEFAULT GETDATE()
        )
    END
END;
GO
EXEC sp_crear_tabla_carritos;


CREATE PROCEDURE sp_crear_tabla_pedidos
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Pedidos' AND xtype='U')
    BEGIN
        CREATE TABLE Pedidos (
            PedidoID INT PRIMARY KEY IDENTITY,
            UsuarioID INT FOREIGN KEY REFERENCES Usuarios(UsuarioID),
            FechaPedido DATE NOT NULL,
            Estado VARCHAR(20) CHECK (Estado IN ('Pendiente','Pagado','Enviado','Entregado'))
        )
    END
END;
GO
EXEC sp_crear_tabla_pedidos;


CREATE PROCEDURE sp_crear_tabla_pagos
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Pagos' AND xtype='U')
    BEGIN
        CREATE TABLE Pagos (
            PagoID INT PRIMARY KEY IDENTITY,
            PedidoID INT FOREIGN KEY REFERENCES Pedidos(PedidoID),
            Monto DECIMAL(10,2) CHECK (Monto > 0),
            FechaPago DATE NOT NULL,
            Metodo VARCHAR(20) CHECK (Metodo IN ('Tarjeta','Efectivo','Transferencia'))
        )
    END
END;
GO
EXEC sp_crear_tabla_pagos;


CREATE PROCEDURE sp_crear_tabla_envios
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Envios' AND xtype='U')
    BEGIN
        CREATE TABLE Envios (
            EnvioID INT PRIMARY KEY IDENTITY,
            PedidoID INT FOREIGN KEY REFERENCES Pedidos(PedidoID),
            Direccion VARCHAR(200) NOT NULL,
            FechaEnvio DATE,
            Estado VARCHAR(20) CHECK (Estado IN ('Pendiente','En camino','Entregado'))
        )
    END
END;
GO
EXEC sp_crear_tabla_envios;


CREATE PROCEDURE sp_insertar_usuario
    @Nombre VARCHAR(50),
    @Email VARCHAR(100),
    @Contraseña VARCHAR(100)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Usuarios WHERE Email = @Email)
    BEGIN
        PRINT 'El correo ya está registrado';
        RETURN;
    END
    INSERT INTO Usuarios (Nombre, Email, Contraseña)
    VALUES (@Nombre, @Email, @Contraseña);
END;
GO


CREATE PROCEDURE sp_insertar_categoria
    @Nombre VARCHAR(50)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Categorias WHERE Nombre = @Nombre)
    BEGIN
        PRINT 'La categoría ya existe';
        RETURN;
    END
    INSERT INTO Categorias (Nombre)
    VALUES (@Nombre);
END;
GO


CREATE PROCEDURE sp_insertar_producto
    @Nombre VARCHAR(100),
    @Precio DECIMAL(10,2),
    @Stock INT,
    @CategoriaID INT
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Categorias WHERE CategoriaID = @CategoriaID)
    BEGIN
        PRINT 'La categoría no existe';
        RETURN;
    END
    INSERT INTO Productos (Nombre, Precio, Stock, CategoriaID)
    VALUES (@Nombre, @Precio, @Stock, @CategoriaID);
END;
GO


CREATE PROCEDURE sp_insertar_carrito
    @UsuarioID INT
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Usuarios WHERE UsuarioID = @UsuarioID)
    BEGIN
        PRINT 'Usuario no existe';
        RETURN;
    END
    INSERT INTO Carritos (UsuarioID)
    VALUES (@UsuarioID);
END;
GO


CREATE PROCEDURE sp_insertar_pedido
    @UsuarioID INT,
    @FechaPedido DATE,
    @Estado VARCHAR(20)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Usuarios WHERE UsuarioID = @UsuarioID)
    BEGIN
        PRINT 'Usuario no existe';
        RETURN;
    END
    INSERT INTO Pedidos (UsuarioID, FechaPedido, Estado)
    VALUES (@UsuarioID, @FechaPedido, @Estado);
END;
GO


CREATE PROCEDURE sp_insertar_pago
    @PedidoID INT,
    @Monto DECIMAL(10,2),
    @FechaPago DATE,
    @Metodo VARCHAR(20)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Pedidos WHERE PedidoID = @PedidoID)
    BEGIN
        PRINT 'Pedido no existe';
        RETURN;
    END
    INSERT INTO Pagos (PedidoID, Monto, FechaPago, Metodo)
    VALUES (@PedidoID, @Monto, @FechaPago, @Metodo);
END;
GO


CREATE PROCEDURE sp_insertar_envio
    @PedidoID INT,
    @Direccion VARCHAR(200),
    @FechaEnvio DATE,
    @Estado VARCHAR(20)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Pedidos WHERE PedidoID = @PedidoID)
    BEGIN
        PRINT 'Pedido no existe';
        RETURN;
    END
    INSERT INTO Envios (PedidoID, Direccion, FechaEnvio, Estado)
    VALUES (@PedidoID, @Direccion, @FechaEnvio, @Estado);
END;
GO


CREATE VIEW vw_productos_mas_vendidos AS
SELECT p.Nombre, COUNT(pe.PedidoID) AS TotalPedidos
FROM Productos p
JOIN Pedidos pe ON pe.UsuarioID IS NOT NULL 
GROUP BY p.Nombre;
GO


CREATE VIEW vw_usuarios_pedidos AS
SELECT u.Nombre, pe.PedidoID, pe.FechaPedido, pe.Estado
FROM Usuarios u
JOIN Pedidos pe ON u.UsuarioID = pe.UsuarioID;
GO

CREATE VIEW vw_pedidos_pagos AS
SELECT pe.PedidoID, pe.Estado, pa.Monto, pa.Metodo, pa.FechaPago
FROM Pedidos pe
JOIN Pagos pa ON pe.PedidoID = pa.PedidoID;
GO

CREATE VIEW vw_envios_pendientes AS
SELECT e.EnvioID, e.Direccion, e.Estado, pe.FechaPedido
FROM Envios e
JOIN Pedidos pe ON e.PedidoID = pe.PedidoID
WHERE e.Estado = 'Pendiente';
GO


CREATE VIEW vw_ventas_por_usuario AS
SELECT u.Nombre, SUM(pa.Monto) AS TotalGastado
FROM Usuarios u
JOIN Pedidos pe ON u.UsuarioID = pe.UsuarioID
JOIN Pagos pa ON pe.PedidoID = pa.PedidoID
GROUP BY u.Nombre;
GO
