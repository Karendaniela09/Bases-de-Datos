
CREATE DATABASE BancoDB;
GO
USE BancoDB;
GO


   CREACIÓN DE TABLAS (con SP)
   

CREATE PROCEDURE sp_crear_tabla_clientes
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Clientes' AND xtype='U')
    BEGIN
        CREATE TABLE Clientes (
            ClienteID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Apellido VARCHAR(50) NOT NULL,
            Email VARCHAR(100) UNIQUE NOT NULL,
            Telefono VARCHAR(20),
            FechaRegistro DATE DEFAULT GETDATE()
        )
    END
END;
GO
EXEC sp_crear_tabla_clientes;
GO


CREATE PROCEDURE sp_crear_tabla_cuentas
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Cuentas' AND xtype='U')
    BEGIN
        CREATE TABLE Cuentas (
            CuentaID INT PRIMARY KEY IDENTITY,
            ClienteID INT FOREIGN KEY REFERENCES Clientes(ClienteID),
            NumeroCuenta VARCHAR(20) UNIQUE NOT NULL,
            Saldo DECIMAL(12,2) CHECK(Saldo >= 0),
            TipoCuenta VARCHAR(20) CHECK(TipoCuenta IN ('Ahorros','Corriente')),
            FechaApertura DATE DEFAULT GETDATE()
        )
    END
END;
GO
EXEC sp_crear_tabla_cuentas;
GO

CREATE PROCEDURE sp_crear_tabla_transacciones
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Transacciones' AND xtype='U')
    BEGIN
        CREATE TABLE Transacciones (
            TransaccionID INT PRIMARY KEY IDENTITY,
            CuentaID INT FOREIGN KEY REFERENCES Cuentas(CuentaID),
            Monto DECIMAL(12,2) NOT NULL,
            Tipo VARCHAR(20) CHECK(Tipo IN ('Depósito','Retiro','Transferencia')),
            Fecha DATETIME DEFAULT GETDATE()
        )
    END
END;
GO
EXEC sp_crear_tabla_transacciones;
GO


CREATE PROCEDURE sp_crear_tabla_prestamos
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Prestamos' AND xtype='U')
    BEGIN
        CREATE TABLE Prestamos (
            PrestamoID INT PRIMARY KEY IDENTITY,
            ClienteID INT FOREIGN KEY REFERENCES Clientes(ClienteID),
            Monto DECIMAL(12,2) NOT NULL CHECK(Monto > 0),
            Interes DECIMAL(5,2) NOT NULL,
            Estado VARCHAR(20) CHECK(Estado IN ('Activo','Pagado','Mora')),
            FechaInicio DATE DEFAULT GETDATE()
        )
    END
END;
GO
EXEC sp_crear_tabla_prestamos;
GO


CREATE PROCEDURE sp_crear_tabla_sucursales
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Sucursales' AND xtype='U')
    BEGIN
        CREATE TABLE Sucursales (
            SucursalID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Ciudad VARCHAR(50) NOT NULL,
            Direccion VARCHAR(100)
        )
    END
END;
GO
EXEC sp_crear_tabla_sucursales;
GO


CREATE PROCEDURE sp_crear_tabla_empleados
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Empleados' AND xtype='U')
    BEGIN
        CREATE TABLE Empleados (
            EmpleadoID INT PRIMARY KEY IDENTITY,
            Nombre VARCHAR(50) NOT NULL,
            Apellido VARCHAR(50) NOT NULL,
            Cargo VARCHAR(50),
            SucursalID INT FOREIGN KEY REFERENCES Sucursales(SucursalID),
            FechaIngreso DATE DEFAULT GETDATE()
        )
    END
END;
GO
EXEC sp_crear_tabla_empleados;
GO

CREATE PROCEDURE sp_crear_tabla_reportes
AS
BEGIN
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Reportes' AND xtype='U')
    BEGIN
        CREATE TABLE Reportes (
            ReporteID INT PRIMARY KEY IDENTITY,
            Descripcion VARCHAR(200),
            FechaGeneracion DATE DEFAULT GETDATE()
        )
    END
END;
GO
EXEC sp_crear_tabla_reportes;
GO


CREATE PROCEDURE sp_insertar_cliente
    @Nombre VARCHAR(50),
    @Apellido VARCHAR(50),
    @Email VARCHAR(100),
    @Telefono VARCHAR(20)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Clientes WHERE Email = @Email)
    BEGIN
        PRINT 'El email ya está registrado.';
        RETURN;
    END
    INSERT INTO Clientes (Nombre, Apellido, Email, Telefono)
    VALUES (@Nombre, @Apellido, @Email, @Telefono)
END;
GO

CREATE PROCEDURE sp_insertar_cuenta
    @ClienteID INT,
    @NumeroCuenta VARCHAR(20),
    @Saldo DECIMAL(12,2),
    @TipoCuenta VARCHAR(20)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Clientes WHERE ClienteID = @ClienteID)
    BEGIN
        PRINT 'Cliente no existe';
        RETURN;
    END
    INSERT INTO Cuentas (ClienteID, NumeroCuenta, Saldo, TipoCuenta)
    VALUES (@ClienteID, @NumeroCuenta, @Saldo, @TipoCuenta)
END;
GO

CREATE PROCEDURE sp_insertar_transaccion
    @CuentaID INT,
    @Monto DECIMAL(12,2),
    @Tipo VARCHAR(20)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Cuentas WHERE CuentaID = @CuentaID)
    BEGIN
        PRINT 'Cuenta no existe';
        RETURN;
    END
    INSERT INTO Transacciones (CuentaID, Monto, Tipo)
    VALUES (@CuentaID, @Monto, @Tipo)
END;
GO


CREATE PROCEDURE sp_insertar_prestamo
    @ClienteID INT,
    @Monto DECIMAL(12,2),
    @Interes DECIMAL(5,2),
    @Estado VARCHAR(20)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Clientes WHERE ClienteID = @ClienteID)
    BEGIN
        PRINT 'Cliente no existe';
        RETURN;
    END
    INSERT INTO Prestamos (ClienteID, Monto, Interes, Estado)
    VALUES (@ClienteID, @Monto, @Interes, @Estado)
END;
GO


CREATE PROCEDURE sp_insertar_sucursal
    @Nombre VARCHAR(50),
    @Ciudad VARCHAR(50),
    @Direccion VARCHAR(100)
AS
BEGIN
    INSERT INTO Sucursales (Nombre, Ciudad, Direccion)
    VALUES (@Nombre, @Ciudad, @Direccion)
END;
GO


CREATE PROCEDURE sp_insertar_empleado
    @Nombre VARCHAR(50),
    @Apellido VARCHAR(50),
    @Cargo VARCHAR(50),
    @SucursalID INT
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Sucursales WHERE SucursalID = @SucursalID)
    BEGIN
        PRINT 'Sucursal no existe';
        RETURN;
    END
    INSERT INTO Empleados (Nombre, Apellido, Cargo, SucursalID)
    VALUES (@Nombre, @Apellido, @Cargo, @SucursalID)
END;
GO


CREATE PROCEDURE sp_insertar_reporte
    @Descripcion VARCHAR(200)
AS
BEGIN
    INSERT INTO Reportes (Descripcion) VALUES (@Descripcion)
END;
GO

EXEC sp_insertar_cliente 'Juan','Pérez','juanp@gmail.com','3001111111';
EXEC sp_insertar_cliente 'Ana','Martínez','ana.m@gmail.com','3002222222';
EXEC sp_insertar_cliente 'Luis','Gómez','luisg@gmail.com','3003333333';
EXEC sp_insertar_cliente 'María','López','marial@gmail.com','3004444444';
EXEC sp_insertar_cliente 'Pedro','Ramírez','pedror@gmail.com','3005555555';
EXEC sp_insertar_cliente 'Lucía','Fernández','luciaf@gmail.com','3006666666';
EXEC sp_insertar_cliente 'Carlos','Torres','carlost@gmail.com','3007777777';
EXEC sp_insertar_cliente 'Laura','Hernández','laurah@gmail.com','3008888888';
EXEC sp_insertar_cliente 'Diego','Castro','diegoc@gmail.com','3009999999';
EXEC sp_insertar_cliente 'Paola','Jiménez','paolaj@gmail.com','3010000000';


EXEC sp_insertar_sucursal 'Sucursal Centro','Bogotá','Calle 10 #5-20';
EXEC sp_insertar_sucursal 'Sucursal Norte','Bogotá','Cra 45 #120-55';
EXEC sp_insertar_sucursal 'Sucursal Sur','Medellín','Calle 80 #30-40';
EXEC sp_insertar_sucursal 'Sucursal Cali','Cali','Av. Colombia #45-33';
EXEC sp_insertar_sucursal 'Sucursal Cartagena','Cartagena','Cra 8 #20-10';
EXEC sp_insertar_sucursal 'Sucursal Bucaramanga','Bucaramanga','Calle 15 #8-22';
EXEC sp_insertar_sucursal 'Sucursal Barranquilla','Barranquilla','Av. 40 #18-99';
EXEC sp_insertar_sucursal 'Sucursal Pereira','Pereira','Cra 12 #6-33';
EXEC sp_insertar_sucursal 'Sucursal Manizales','Manizales','Calle 22 #15-44';
EXEC sp_insertar_sucursal 'Sucursal Pasto','Pasto','Cra 7 #25-10';


EXEC sp_insertar_empleado 'Andrés','Santos','Gerente',1;
EXEC sp_insertar_empleado 'Beatriz','Mora','Cajera',1;
EXEC sp_insertar_empleado 'Camilo','Pardo','Asesor',2;
EXEC sp_insertar_empleado 'Daniela','Vargas','Asesor',2;
EXEC sp_insertar_empleado 'Esteban','Suárez','Gerente',3;
EXEC sp_insertar_empleado 'Felipe','López','Cajero',3;
EXEC sp_insertar_empleado 'Gabriela','Moreno','Asesora',4;
EXEC sp_insertar_empleado 'Héctor','Silva','Asesor',5;
EXEC sp_insertar_empleado 'Isabel','Cruz','Gerente',6;
EXEC sp_insertar_empleado 'Jorge','Castillo','Cajero',7;


EXEC sp_insertar_cuenta 1,'1001',500000,'Ahorros';
EXEC sp_insertar_cuenta 2,'1002',1500000,'Corriente';
EXEC sp_insertar_cuenta 3,'1003',250000,'Ahorros';
EXEC sp_insertar_cuenta 4,'1004',750000,'Ahorros';
EXEC sp_insertar_cuenta 5,'1005',1000000,'Corriente';
EXEC sp_insertar_cuenta 6,'1006',900000,'Ahorros';
EXEC sp_insertar_cuenta 7,'1007',600000,'Corriente';
EXEC sp_insertar_cuenta 8,'1008',1200000,'Ahorros';
EXEC sp_insertar_cuenta 9,'1009',350000,'Ahorros';
EXEC sp_insertar_cuenta 10,'1010',800000,'Corriente';


EXEC sp_insertar_transaccion 1,200000,'Depósito';
EXEC sp_insertar_transaccion 2,50000,'Retiro';
EXEC sp_insertar_transaccion 3,100000,'Depósito';
EXEC sp_insertar_transaccion 4,30000,'Retiro';
EXEC sp_insertar_transaccion 5,250000,'Depósito';
EXEC sp_insertar_transaccion 6,80000,'Retiro';
EXEC sp_insertar_transaccion 7,150000,'Depósito';
EXEC sp_insertar_transaccion 8,200000,'Transferencia';
EXEC sp_insertar_transaccion 9,50000,'Retiro';
EXEC sp_insertar_transaccion 10,100000,'Depósito';


EXEC sp_insertar_prestamo 1,2000000,5.5,'Activo';
EXEC sp_insertar_prestamo 2,3500000,6.2,'Activo';
EXEC sp_insertar_prestamo 3,1000000,4.5,'Pagado';
EXEC sp_insertar_prestamo 4,5000000,7.0,'Mora';
EXEC sp_insertar_prestamo 5,2200000,5.0,'Activo';
EXEC sp_insertar_prestamo 6,1500000,4.8,'Pagado';
EXEC sp_insertar_prestamo 7,3300000,6.5,'Mora';
EXEC sp_insertar_prestamo 8,4000000,6.9,'Activo';
EXEC sp_insertar_prestamo 9,1800000,5.3,'Pagado';
EXEC sp_insertar_prestamo 10,2700000,5.7,'Activo';


EXEC sp_insertar_reporte 'Clientes con préstamos activos';
EXEC sp_insertar_reporte 'Saldo total por cliente';
EXEC sp_insertar_reporte 'Transacciones del último mes';
EXEC sp_insertar_reporte 'Préstamos en mora';
EXEC sp_insertar_reporte 'Empleados por sucursal';
EXEC sp_insertar_reporte 'Reporte de ingresos por cuentas';
EXEC sp_insertar_reporte 'Clientes frecuentes';
EXEC sp_insertar_reporte 'Historial de pagos';
EXEC sp_insertar_reporte 'Reporte general de préstamos';
EXEC sp_insertar_reporte 'Resumen de transacciones';


CREATE VIEW vw_transacciones_mes AS
SELECT t.TransaccionID, c.NumeroCuenta, t.Monto, t.Tipo, t.Fecha
FROM Transacciones t
JOIN Cuentas c ON t.CuentaID = c.CuentaID
WHERE MONTH(t.Fecha) = MONTH(GETDATE()) AND YEAR(t.Fecha) = YEAR(GETDATE());
GO


CREATE VIEW vw_prestamos_mora AS
SELECT p.PrestamoID, c.Nombre, p.Monto, p.FechaInicio
FROM Prestamos p
JOIN Clientes c ON p.ClienteID = c.ClienteID
WHERE p.Estado = 'Mora';
GO

CREATE VIEW vw_empleados_sucursal AS
SELECT s.Nombre AS Sucursal, e.Nombre, e.Apellido, e.Cargo
FROM Empleados e
JOIN Sucursales s ON e.SucursalID = s.SucursalID;
GO

